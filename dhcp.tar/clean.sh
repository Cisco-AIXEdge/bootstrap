#!/bin/bash
sudo rm /flash/guest-share/dhcp.tar
sudo rm -rf /home/guestshell/*.rpm
