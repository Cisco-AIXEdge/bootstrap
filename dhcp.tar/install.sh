#!/bin/bash
sudo dnf -y --disablerepo=* localinstall *.rpm
